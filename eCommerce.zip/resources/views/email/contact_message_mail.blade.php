<h3>Hello Mr.</h3>

<p>I am : {{ $mail_request->full_name }}</p>

<p>My email is : {{ $mail_request->email }}</p>

<p>My subject is: {{ $mail_request->subject }}</p>

<p>My message is: {{ $mail_request->message }}</p>

No reply please. 
HR department