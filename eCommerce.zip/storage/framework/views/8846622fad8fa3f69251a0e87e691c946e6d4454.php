<?php $__env->startSection('body_part'); ?>
<div class="container-fluid">
   <div class="row mt-3 mb-3">
      <div class="col-8">
         <div class="card mb-3 ">
            <div class="card-header bg-success text-light text-center">Product list</div>
            <div class="card-body">
               <?php if(session('delete')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('delete')); ?>

                  </div>
               <?php endif; ?>
               <?php if(session('restore')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('restore')); ?>

                  </div>
               <?php endif; ?>
               <?php if(session('edit')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('edit')); ?>

                  </div>
               <?php endif; ?>
               <table class="table table-striped table-dark">
                  <thead>
                     <tr>
                        <th>No</th>
                        <th>Category Name</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Alert_Q</th>
                        <th>Image</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                           <td><?php echo e($loop->index + $products->firstItem()); ?></td>
                           <td><?php echo e($product->name); ?></td>
                           <td><?php echo e($product-> relationToTable-> category_name); ?></td>                        
                           <td><?php echo e(str_limit($product->description, 20)); ?></td>
                           <td><?php echo e($product->price); ?></td>
                           <td><?php echo e($product->quantity); ?></td>
                           <td><?php echo e($product->alert_quantity); ?></td>
                           <td>
                              <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($product->product_image); ?>" alt="No Image found" width="60">
                           </td>
                           <td>
                              <div class="btn-group" role="group">
                                 <a href="<?php echo e(url('delete_product')); ?>/<?php echo e($product->id); ?>" class="btn btn-sm btn-danger">Delete</a>
                                 <a href="<?php echo e(url('edit_product')); ?>/<?php echo e($product->id); ?>" class="btn btn-sm btn-info">Edit</a>
                              </div>
                           </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center text-danger">
                           <td colspan="9">No data found...</td>
                        </tr>
                     <?php endif; ?>
                  </tbody>
               </table>
               <?php echo e($products->links()); ?>

            </div>
         </div>
         <div class="card">
            <div class="card-header bg-danger text-light text-center">Deleted product</div>
            <div class="card-body">
               <?php if(session('forceDelete')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('forceDelete')); ?>

                  </div>
               <?php endif; ?>
               
               <table class="table table-striped table-dark">
                  <thead>
                     <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Image</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $deleted_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                           <td><?php echo e($loop->index + $deleted_products->firstItem()); ?></td>
                           <td><?php echo e($deleted_product->name); ?></td>
                           <td><?php echo e(str_limit($deleted_product->description, 20)); ?></td>
                           <td><?php echo e($deleted_product->price); ?></td>
                           <td><?php echo e($deleted_product->quantity); ?></td>
                           <td>
                              <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($deleted_product->product_image); ?>" alt="No image found" width="60">
                           </td>
                           <td>
                              <div class="btn-group" role="group">
                                 <a href="<?php echo e(url('restore_product')); ?>/<?php echo e($deleted_product->id); ?>" class="btn btn-sm btn-success">Restore</a>
                                 <a href="<?php echo e(url('force_delete')); ?>/<?php echo e($deleted_product->id); ?>" class="btn btn-sm btn-danger">Force delete</a>
                              </div>
                           </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center bg-danger">
                           <td colspan="8">No data found...</td>
                        </tr>
                     <?php endif; ?>                     
                  </tbody>
               </table>
               <?php echo e($deleted_products->links()); ?>

            </div>
         </div>
      </div>
      <div class="col-4 offset-">
         <div class="card">
            <div class="card-header bg-success text-light text-center">
               Add Product
            </div>
            <div class="card-body">
               <?php if(session('insert')): ?>
                  <div class="alert alert-success">
                     <?php echo e(session('insert')); ?>

                  </div>
               <?php endif; ?>
               <?php if($errors-> all()): ?>
                  <div class="alert alert-danger">
                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><?php echo e($error); ?></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               <?php endif; ?>
               <form action="<?php echo e(url('insert_product')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                     <label>Category Name</label>
                     <select class="form-control" name="category_id">
                        <option value="">-Select One- </option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
                  <div class="form-group">
                     <label>Product Name</label>
                     <input type="text" class="form-control" name="name" placeholder="Product Name" value="<?php echo e(old('name')); ?>">
                  </div>
                  <div class="form-group">
                     <label>Product Description</label>
                     <input type="text" class="form-control" name="description" placeholder="Description" value="<?php echo e(old('description')); ?>">
                  </div>
                  <div class="form-group">
                     <label>Product Price</label>
                     <input type="text" class="form-control" name="price" placeholder="Price" value="<?php echo e(old('price')); ?>">
                  </div>
                  <div class="form-group">
                     <label>Product Quantity</label>
                     <input type="text" class="form-control" name="quantity" placeholder="Quantity" value="<?php echo e(old('quantity')); ?>">
                  </div>
                  <div class="form-group">
                     <label>Alert Quantity</label>
                     <input type="text" class="form-control" name="alert_quantity" placeholder="Alert_quantity" value="<?php echo e(old('alert_quantity')); ?>">
                  </div>
                  <div class="form-group">
                     <label>Product Image</label>
                     <input type="file" class="form-control" name="product_image">
                  </div>
                  <button type="submit" class="btn btn-info">Add product</button>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/product/Add_Product.blade.php ENDPATH**/ ?>