   <?php $__env->startSection('body_part'); ?>   

      <div class="navbar navbar-expand-lg g-success">
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
               <?php
                   $menus= App\Category::where('menu_status', 1)->get();
                   // $menus= App\Category::latest()->take(3)->get();
                  //$menus= App\Category::all();
               ?>

               <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item">
                     <a class="nav-lin btn text-light btn-primary mr-1" href="<?php echo e(url('category_wise_menu')); ?>/<?php echo e($menu->id); ?>"><?php echo e($menu->category_name); ?></a>
                  </li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                 
            </ul>
         </div>
      </div>
   
      <div class="row">
         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-sm-12 category_wise">
               <div class="card">
                  <div class="card-header text-center text-light bg-success p-1">Product Name: <?php echo e($product->name); ?></div>
                     <div class="card-body p-2 category_wise_body">
                        <a href="<?php echo e(url('view_product')); ?>/<?php echo e($product->id); ?>">
                           <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($product->product_image); ?>" width="100%" height="180">
                        </a>
                        <div class="pt-3 pb-0">
                           <p class="float-left ">Price: $<?php echo e($product->price); ?></p>
                           <p class="float-right">
                              <a href="<?php echo e(url('view_product')); ?>/<?php echo e($product->id); ?>" class="btn btn-info btn-sm">Add To Cart</a>
                           </p>
                        </div>
                     </div>
               </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/product/category_wise_menu.blade.php ENDPATH**/ ?>