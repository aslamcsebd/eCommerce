   <?php $__env->startSection('body_part'); ?>
      <div class="container-fluid">
         <div class="row mt-3">
            <div class="col-8">
               <div class="card mb-3 ">
                   <div class="card-header bg-success text-light text-center">Category List</div>

                   <div class="card-body">
                       <?php if(session('delete')): ?>
                           <div class="alert alert-success" role="alert">
                               <?php echo e(session('delete')); ?>

                           </div>
                       <?php endif; ?>                       
                     <table class="table table-striped table-dark">
                       <thead>
                         <tr>
                           <th>SL. No</th>
                           <th>Category Name</th>
                           <th>Menu Status</th>
                           <th>Created At</th>
                           <th>Action</th>
                         </tr>
                       </thead>
                       <tbody>
                           <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                         <tr>
                           <td><?php echo e($loop->index + 1); ?></td>
                           <td><?php echo e($category->category_name); ?></td>
                           <td><?php echo e(($category->menu_status == 1) ? 'Yes':'No'); ?></td>
                           <td>
                              <?php echo e($category->created_at->format('d-M-Y  h:i:s A')); ?>

                              <br>
                              <?php echo e($category->created_at->diffForHumans()); ?>

                           </td>
                           
                           <td>
                              <div class="btn-group" role="group">
                                 <a href="<?php echo e(url('change_category')); ?>/<?php echo e($category->id); ?>" class="btn btn-sm btn-danger">Change</a>
                              </div>                           
                           </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <tr class="text-center text-danger">
                              <td colspan="8">No data found...</td>
                           </tr>
                         <?php endif; ?>
                                              
                       </tbody>
                     </table>
                     <?php echo e($categories->links()); ?>

                   </div>
               </div>
           </div>
            <div class="col-4 offset-">
               <div class="card">
                  <div class="card-header bg-success text-light text-center">
                     Add Category
                  </div>               
                  <div class="card-body">
                     <?php if(session('insert')): ?>
                        <div class="alert alert-success">
                           <?php echo e(session('insert')); ?>

                        </div>
                     <?php endif; ?>

                     <?php if($errors-> all()): ?>
                        <div class="alert alert-danger">
                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     <?php endif; ?>

                     <form action="<?php echo e(url('insert_category')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                           <label>Category Name</label>
                           <input type="text" class="form-control" name="category_name" placeholder="Category Name" value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="form-group">
                           <input type="checkbox" id="menu" name="menu_status" value="1">
                           <label for="menu">Use as Menu</label>
                        </div>                            
                        <button type="submit" class="btn btn-info">Add Category</button>
                     </form>                 
                  </div>               
               </div>            
            </div>         
         </div>      
      </div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/category/all_category.blade.php ENDPATH**/ ?>