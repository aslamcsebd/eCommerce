   
<?php $__env->startSection('body_part'); ?>   
   <div class="row justify-content-center">
      <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 mt-4">

         <div class="card">
            <div class="card-header badge-success text-light text-center">Selected product</div>
               <div class="card-body row justify-content-center">
                  <div class="col-lg-4 col-md-6 col-sm-6">
                     <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($single_product_info->product_image); ?>" width="260">
                  </div>
                  <div class="col-lg col-md-6 col-sm-6 ml-3">
                     <h5>Name: <?php echo e($single_product_info->name); ?></h5>
                     <h6>Category Name: <?php echo e($single_product_info-> relationToTable-> category_name); ?></h6>
                     
                     <h5>Price2: $<?php echo e($single_product_info->price); ?></h5>
                     <p> <b>Details : </b> <?php echo e($single_product_info->description); ?></p>
                     <a href="<?php echo e(url('add_to_card')); ?>/<?php echo e($single_product_info->id); ?>" class="btn btn-info btn-sm">Add To Cart</a>
                  </div>                  
               </div>                                      
         </div>
      </div>                
   </div>
   <div class="row justify-content-center">
      <div class="col-10">
         <div class="card my-4">
            <div class="card-header text-light bg-primary text-center">Related Product</div>
               <div class="card-body row justify-content-center">
                  <?php $__empty_1 = true; $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <div class="col-12 col-lg-3 col-md-4 col-sm-6 col-xs-12 welcomeProduct">
                        <div class="card">
                           <div class="card-header text-center text-light bg-success p-1">Product : <?php echo e($related_product->name); ?></div>
                           <div class="card-body p-2">
                              <a href="<?php echo e(url('view_product')); ?>/<?php echo e($related_product->id); ?>">
                                 <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($related_product->product_image); ?>" width="100%" height="180">
                              </a>
                              <div class="pt-3 pb-0">
                                 <p class="float-left ">Price: $<?php echo e($related_product->price); ?></p>
                                 <p class="float-right">
                                   <a href="<?php echo e(url('view_product')); ?>/<?php echo e($related_product->id); ?>" class="btn btn-info btn-sm">Add To Cart</a>   
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     No related product avaiable...
                  <?php endif; ?>     
               </div>
         </div>
      </div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/product/View_Product.blade.php ENDPATH**/ ?>