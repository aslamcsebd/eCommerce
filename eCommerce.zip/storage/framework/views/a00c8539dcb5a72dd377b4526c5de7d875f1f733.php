<?php $__env->startSection('body_part'); ?>
<div class="container-fluid">
   <div class="row justify-content-center">
      <div class="col-10 my-5 border-danger">
         <table class="table table-striped border">
            <thead class="thead-dark">
               <tr>
                  <th>SL. No</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total</th>
               </tr>
            </thead>
            <tbody>
               <?php $__empty_1 = true; $__currentLoopData = $card_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>
                  <td>
                     <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($card_item->relationToCard->product_image); ?>" width="70">
                     <?php if($card_item->relationToCard->quantity < $card_item->product_quantity): ?>
                     <div class="alert alert-danger" width="20px">
                        Please remove
                     </div>
                     <?php endif; ?>
                  </td>
                  <td>
                     <?php echo e($card_item->relationToCard->name); ?>

                     <p>
                        <small>
                        <a href="<?php echo e(url('card_delete')); ?>/<?php echo e($card_item->id); ?>" >Delete Item</a>
                        </small>
                     </p>
                  </td>
                  <td>$<?php echo e($card_item->relationToCard->price); ?></td>
                  <td>
                     <div class="quantity_input">
                        <span>Qty : </span>
                        <input type="number" value="<?php echo e($card_item->product_quantity); ?>">
                     </div>
                  </td>
                  <td>
                     <?php echo e(($card_item->product_quantity)
                     *
                     ($card_item->relationToCard->price)); ?>

                  </td>
                  
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr class="text-center text-danger">
                     <td colspan="6">No data found...</td>
                  </tr>
               <?php endif; ?>                     
            </tbody>
         </table>
         <div class="row mb-2">
            <div class="col"></div>
            <div class="col">
               <a class="btn btn-success" href="<?php echo e('/'); ?>">Continue Shopping</a>
            </div>
            <div class="col"></div>
            <div class="col">
               <a class="btn btn-danger" href="<?php echo e(url('delete_all_cart')); ?>">Clear Cart</a>
            </div>
            <div class="col">
               <a class="btn btn-info" href="">Update Cart</a>
            </div>
         </div>
         
         <?php if(session('delete_sms')): ?>
            <div class="alert alert-danger">
               <?php echo e(session('delete_sms')); ?>

            </div>
         <?php endif; ?>            
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/card/card.blade.php ENDPATH**/ ?>