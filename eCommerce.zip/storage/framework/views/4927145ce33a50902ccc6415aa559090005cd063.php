   <?php $__env->startSection('body_part'); ?>
      <div class="container-fluid">
         <br>
         <div class="row justify-content-center">
            <div class="col-8">
               <div class="card">
                  <div class="card-header badge-success text-center">Contact Now</div>               
                  <div class="card-body">
                     <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                           <?php echo e(session('status')); ?>

                        </div>
                     <?php endif; ?>

                     <?php if($errors-> all()): ?>
                        <div class="alert alert-danger">
                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     <?php endif; ?>

                     <form action="<?php echo e(url('contact_insert')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>                        
                        <div class="row">                           
                           <div class="form-group col-md-6">
                              <input type="text" class="form-control" name="full_name" placeholder="Full Name" value="<?php echo e(old('full_name')); ?>">
                           </div>
                           <div class="form-group col-md-6">
                              <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                           </div>
                        </div>
                        <div class="form-group">
                           <input type="text" class="form-control" name="subject" placeholder="subject" value="<?php echo e(old('subject')); ?>">
                        </div>
                        <div class="form-group">
                           <textarea type="text" class="form-control" name="message" rows="8" placeholder="Message" value="<?php echo e(old('message')); ?>"></textarea>
                        </div>    
                        <button type="submit" class="btn btn-info">Send Message</button>                                     
                     </form>                 
                  </div>               
               </div>            
            </div>         
         </div>      
      </div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/layouts/contact.blade.php ENDPATH**/ ?>