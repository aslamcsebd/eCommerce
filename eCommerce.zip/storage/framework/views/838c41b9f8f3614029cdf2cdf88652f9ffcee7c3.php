   <?php $__env->startSection('body_part'); ?>   

      <div class="navbar navbar-expand-lg g-success">
         <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
               <?php
                   $menus= App\Category::where('menu_status', 1)->get();
               ?>
               <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item">
                     <a class="nav-lin btn btn-primary mr-1 text-light" href="<?php echo e(url('category_wise_menu')); ?>/<?php echo e($menu->id); ?>"><?php echo e($menu->category_name); ?></a>
                  </li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                 
            </ul>
         </div>
      </div>
   
      <div class="row">
         <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-lg-3 col-md-4 col-sm-6 col-xs-12 welcomeProduct">
               <div class="card">
                  <div class="card-header text-center text-light bg-success p-1">Product Name: <?php echo e($product->name); ?></div>
                  <div class="card-body p-2">
                     <a href="<?php echo e(url('view_product')); ?>/<?php echo e($product->id); ?>">
                        <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($product->product_image); ?>" width="100%" height="180">
                     </a>
                     <div class="pt-3 pb-0">
                        <p class="float-left ">Price: $<?php echo e($product->price); ?></p>
                        <p class="float-right">
                           <?php if( $product->quantity > 0 ): ?>
                              <a href="<?php echo e(url('view_product')); ?>/<?php echo e($product->id); ?>" class="btn btn-info btn-sm">Add To Cart</a>                           
                           <?php else: ?>
                              <div class="alert alert-danger">
                                 No product available
                              </div>
                           <?php endif; ?>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="card mt-4 mb-4">
         <div class="card-header pb-0 badge-info">
            <div id="filters" class="button-group">  
               <button class="button is-checked" data-filter="*">Show all</button>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <button class="button" data-filter=".aslam<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>         
         </div>
         <div class="card-body">
            <div class="grid row">
               <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-12 col-lg-3 py-2 col-md-4 col-sm-6 element-item all aslam<?php echo e($product->category_id); ?>">
                     <div class="card">
                        <div class="card-header text-light text-center p-1 bg-success"><?php echo e($product->name); ?></div>
                        <div class="card-body p-1">
                           <a href="<?php echo e(url('view_product')); ?>/<?php echo e($product->id); ?>">
                              <img src="<?php echo e(asset('Full_Project/images/product_images')); ?>/<?php echo e($product->product_image); ?>" width="100%" height="180">
                           </a>
                           <p class="p-1 pb-0">Price: $<?php echo e($product->price); ?></p>                  
                        </div>
                     </div>
                  </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/welcome.blade.php ENDPATH**/ ?>