   <?php $__env->startSection('body_part'); ?>
      <div class="container-fluid">
         <div class="row justify-content-center">
            <div class="col-10">
               <div class="card mt-4 ">
                   <div class="card-header bg-success text-center">All message</div>
                   <div class="card-body">
                     <table class="table">
                                             
                       <thead class="thead-dark">
                         <tr>
                           <th>SL. No</th>
                           <th>Name</th>
                           <th>Email</th>
                           <th>Subject</th>
                           <th>Message</th>
                           <th>Action</th>                  
                         </tr>
                       </thead>
                       <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $all_smses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_sms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>  
                         <tr class=<?php echo e(($all_sms->read_status==1)? "bg-info":""); ?>>
                           <td><?php echo e($loop->index + 1); ?></td>
                           <td><?php echo e($all_sms->full_name); ?></td>
                           <td><?php echo e($all_sms->email); ?></td>
                           <td><?php echo e($all_sms->subject); ?></td>
                           <td><?php echo e(str_limit($all_sms->message, 20)); ?></td>
                           <td>
                              <div class="btn-group" role="group">
                                 <a href="<?php echo e(url('view_sms')); ?>/<?php echo e($all_sms->id); ?>" class="btn btn-sm btn-success">View</a>
                              <a href="<?php echo e(url('delete_sms')); ?>/<?php echo e($all_sms->id); ?>" class="btn btn-sm btn-danger">Delete</a>
                              </div>                           
                           </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <tr class="text-center text-danger">
                              <td colspan="6">No data found...</td>
                           </tr>
                         <?php endif; ?>
                                              
                       </tbody>
                     </table>
                     <?php echo e($all_smses->links()); ?>

                     <?php if(session('delete_sms')): ?>
                        <div class="alert alert-danger">
                           <?php echo e(session('delete_sms')); ?>

                        </div>
                     <?php endif; ?>
                   </div>
               </div>  
            </div>
         </div>
      </div>
   <?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layouts.Head_Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eCommerce\resources\views/layouts/view_sms.blade.php ENDPATH**/ ?>