## Laravel E-commerce website

<a href="http://lr.rentanybd.com/" target="_blank">
   <img src="storage/images/click_me.png" width="auto" height="260">
</a>